#!/bin/bash - 
#===============================================================================
#
#          FILE:  
# 
#         USAGE:  ./ 
# 
#   DESCRIPTION:  
# 
#       OPTIONS:  ---
#  REQUIREMENTS:  ---
#          BUGS:  ---
#         NOTES:  ---
#        AUTHOR: LiangHuiQiang 
#  ORGANIZATION: 
#       CREATED: 2012/11/20 11:33:04 中国标准时间
#      REVISION:  ---
#===============================================================================

#set -o nounset                              # Treat unset variables as an error

#===============================================================================
#  GLOBAL DECLARATIONS
#===============================================================================

THIS_PID=$$
export LANG=c
export PATH=$PATH:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/sbin:/usr/local/sbin
SCRIPT_PATH=$(dirname $0);
cd $SCRIPT_PATH;

declare -a ProcDir=/home/cattsoft
declare -a StartScript=start.sh
declare -a ErrorLogFile=err.log

declare -a CATT_PROC_NAME_ZH
declare -a CATT_PROC_NAME
declare -a CATT_PROC_START
declare -i CATT_PROC_NUMBER
declare -i RETVAL=0

#===============================================================================
#  FUNCTION DEFINITIONS
#===============================================================================


#---  FUNCTION  ----------------------------------------------------------------
#          NAME:  getStartScript
#   DESCRIPTION:  
#    PARAMETERS: ProcDIR StartScript Out_File 
#       RETURNS:  
#-------------------------------------------------------------------------------
function getStartScript()
{

    Find_Dir=$1
    Find_File=$2
    Find_Type=f
    Find_Perm=x
    Out_File=$3

    find $Find_Dir -name $Find_File -type $Find_Type -print > $Out_File; 
    
    return 0;
}



#---  FUNCTION  ----------------------------------------------------------------
#          NAME:  getScriptValue
#   DESCRIPTION:  
#    PARAMETERS:  
#       RETURNS:  
#-------------------------------------------------------------------------------
function getScriptValue()
{
    FoundScript="/tmp/.foundproc"
    getStartScript $ProcDir $StartScript $FoundScript;
    i=0
    while read LINE ; do

        MANAGER=`awk -F"=" '$1~/^CATT_PROC_MANAGER/{gsub(/[[:blank:]]*/,"",$2);print $2}' $LINE`
        MANAGER=$((MANAGER+0))
        if [ "$MANAGER" -eq 1 ] ; then
            eval `awk -F"=" '$1~/CATT_PROC/&&$1!~/CATT_PROC_MANAGER/{print $1"[""'$i'""]="$2}' $LINE` 
            #awk -F"=" '$1~/CATT_PROC/&&$1!~/CATT_PROC_MANAGER/{print $1"[""'$i'""]="$2}' $LINE
            eval `echo "CATT_PROC_START[$i]=$LINE"`  
            i=$((i+1))
        fi

    done < $FoundScript;

    CATT_PROC_NUMBER=$i

    rm -f $FoundScript;
    return 0;
}


#---  FUNCTION  ----------------------------------------------------------------
#          NAME:  getProcStat
#   DESCRIPTION:  
#    PARAMETERS:  
#       RETURNS:  
#-------------------------------------------------------------------------------
function getProcStat(){
    PSUM=${#CATT_PROC_NAME[*]}; 
    echo "";
    ps -e o pid,pmem,pcpu,stat,args|head -1|sed 's/PID/进程号/;s/%MEM/内存占用率/;s/%CPU/CPU占用率/;s/STAT/状态/'|awk '{printf("%4s\t%8s\t%6s\t%10s\t%10s\t%10s\n","程序","进程标识",$1,$2,$3,$4)}' 
for val in `seq 0 $((PSUM-1))`
do
   TMP_NAME_ZH=`echo ${CATT_PROC_NAME_ZH[$val]}`
   TMP_NAME=`echo ${CATT_PROC_NAME[$val]}`

   if [ -z "$TMP_NAME" ] ; then
       TMP_NAME="' '"
       fi

   if [ -n "$TMP_NAME_ZH" ] ; then
        P_NAME=$TMP_NAME_ZH
   else
        P_NAME="' '"
   fi   

PS_PROC=`ps aux|grep $TMP_NAME |grep -v grep|wc -l`
if [ $PS_PROC -ne 0 ];then
#printf "%4s %8s" "$P_NAME" "$TMP_NAME" ;
        ps -e o pid,pmem,pcpu,stat,args | grep $TMP_NAME  |awk '$0!~/grep/{printf("%4s\t%8s\t%6s\t%10s\t%10s\t%10s\n","'$P_NAME'","'$TMP_NAME'",$1,$2,$3,$4)}'

else
        printf "%s%s\n" "[未运行]" ${P_NAME}" ("`dirname ${CATT_PROC_START[$val]}`") ">>/tmp/.ps_unrun.tmp 

fi
#ps aux|grep ${PROC_NAME[0]} |grep -v grep
done
echo "";
echo "------------------------------------------";
cat /tmp/.ps_unrun.tmp 2>/dev/null
rm -f /tmp/.ps_unrun.tmp 2>/dev/null
    
}


#---  FUNCTION  ----------------------------------------------------------------
#          NAME:  StartProc
#   DESCRIPTION:  
#    PARAMETERS:  
#       RETURNS:  
#-------------------------------------------------------------------------------

function StartProc(){
    
    if [ "$1" = "all" ] ; then
        Len=${#CATT_PROC_START[*]} 
        for (( CNTR=0; CNTR<$Len; CNTR+=1 )); do
            echo "bash ${CATT_PROC_START[$CNTR]} &" |bash
        done

        fi

}


#===============================================================================
#  MAIN SCRIPT
#===============================================================================





#getScriptValue;

#echo ${CATT_PROC_NAME[@]}
#echo ${CATT_PROC_NAME_ZH[@]}
#echo ${CATT_PROC_START[@]}
#echo ${#CATT_PROC_NAME[*]}
#echo $CATT_PROC_NUMBER;
#getProcStat;


case "$1" in
        list)
                getScriptValue;
                getProcStat;
                ;;
        startall)
                getScriptValue;
                StartProc "all"
        ;;
        *)
                echo $"Usage: $0 {list|startall}"
                RETVAL=2
esac
exit $RETVAL

